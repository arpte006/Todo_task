const express = require("express");
const app = express();
const cors = require("cors");
const pool = require("./database");

//middleware
app.use(cors());
app.use(express.json()); //req.body

//create a todo

app.post("/idexceltodo", async (req, res) => {
    try {
      const { customer_name } = req.body;
      const newTodo = await pool.query(
        "INSERT INTO todo (customer_name) VALUES($1) RETURNING *",
        [customer_name]
      );
  
      res.json(newTodo.rows[0]);
    } catch (err) {
      console.error(err.message);
    }
  });
  
 //get all todos

app.get("/idexceltodo", async (req, res) => {
    try {
      const allTodos = await pool.query("SELECT * FROM todo");
      res.json(allTodos.rows);
    } catch (err) {
      console.error(err.message);
    }
  });
  
  //delete a todo
  
  app.delete("/idexceltodo/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleteTodo = await pool.query("DELETE FROM todo WHERE todo_id = $1", [
        id
      ]);
      res.json("Todo was deleted!");
    } catch (err) {
      console.log(err.message);
    }
  });

app.listen(8080, () => {
    console.log("server has started on port 8080");
  });