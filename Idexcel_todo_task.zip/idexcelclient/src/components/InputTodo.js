import React, { Fragment, useState } from "react";

const InputTodo = () => {
  const [customer_name, setCustomer_name] = useState("");

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const body = { customer_name };
      const response = await fetch("http://localhost:8080/idexceltodo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      window.location = "/";
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <Fragment>
      <h1 className="text-center mt-5"> Customer Todo List</h1>
      <label></label>
      <form className="d-flex mt-5" >
        <input
          type="text"
          className="form-control"
          placeholder="Customer Name"
          value={customer_name}
          onChange={e => setCustomer_name(e.target.value)}
        />
        <button className="btn btn-success" onClick={onSubmitForm}>Create</button>
      </form>
    </Fragment>
  );
};

export default InputTodo;
